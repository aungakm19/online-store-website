<form method="post">
	@csrf
	Category: <input type="text" name="name"> 
	<input type="submit" name="Add">
</form>