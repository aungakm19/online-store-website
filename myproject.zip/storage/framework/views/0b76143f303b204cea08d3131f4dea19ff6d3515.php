<form method="post">
	<?php echo csrf_field(); ?>
	Category: <input type="text" name="name"> 
	<input type="submit" name="Add">
</form><?php /**PATH C:\xampp\htdocs\myproject\resources\views/user/addcategory.blade.php ENDPATH**/ ?>